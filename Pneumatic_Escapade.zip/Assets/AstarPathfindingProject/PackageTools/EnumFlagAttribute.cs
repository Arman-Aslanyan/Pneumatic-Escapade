using UnityEngine;

namespace Pathfinding {
	/// <summary>\author http://wiki.unity3d.com/index.php/EnumFlagPropertyDrawer</summary>
	public class EnumFlagAttribute : PropertyAttribute {
	}
}
